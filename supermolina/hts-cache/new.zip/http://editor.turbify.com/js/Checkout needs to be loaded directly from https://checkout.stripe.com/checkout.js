
<html><head>
<meta http-equiv="content-type" content="text/html;charset=utf-8">
<title>404 Not Found</title>
</head>
<body text=#000000 bgcolor=#ffffff>
<h1>Error: Not Found</h1>
<h2>The requested URL <code>/js/Checkout%20needs%20to%20be%20loaded%20directly%20from%20https://checkout.stripe.com/checkout.js</code> was not found on this server.</h2>
<h2></h2>
</body></html>
